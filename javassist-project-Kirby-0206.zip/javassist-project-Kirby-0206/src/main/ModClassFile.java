package main;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Loader;

public class ModClassFile {
	static String WORK_DIR = System.getProperty("user.dir");
	static String OUTPUT_DIR = WORK_DIR + File.separator + "output";

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] list;
		boolean quit = false;

		do {
			System.out.println("Please enter a class name, a method name, and an index of the method parameter.\n"
					+ "(e.g. ComponentApp, foo, 1 or ServiceApp, bar, 2)\n" + "Key \\\"q\\\" to quit.");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
				if (list[i].equals("q")) {
					System.out.println("You have quit the program.");
					System.exit(0);
				}
			}
			System.out.println("");

			if (list.length != 3) {
				System.out.println("[WRN] Invalid Input size!!\n" + "");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else {
				String className = "target." + list[0];
				String methodName = list[1];
				String indexName = list[2];
				sc.close();
				quit = true;

				try {
					ClassPool pool = ClassPool.getDefault();
					CtClass cc = pool.get(className);
					CtMethod ctMeth = cc.getDeclaredMethod(methodName);

					String printBlock = "{ " + "System.out.println(\"[Inserted] " + className + "." + methodName +"'s parm " + indexName
							+ ": \" + $" + indexName + "); " + "}";

					ctMeth.insertBefore(printBlock);
					Loader loader = new Loader(pool);
					Class<?> c = loader.loadClass(className);
					Method m1 = c.getDeclaredMethod("main", new Class[] { String[].class });
					m1.invoke(null, new Object[] { list });
					cc.writeFile(OUTPUT_DIR);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} while (!quit);
	}

}
